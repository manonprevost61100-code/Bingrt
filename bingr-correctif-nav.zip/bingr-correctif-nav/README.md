# Bingr — Correctif : bouton retour à l'accueil

Ajoute un lien "← Accueil" sur les 3 écrans qui n'en avaient pas :
Calendrier, Fiche média, Recherche.

## Installation

```bash
git pull
unzip bingr-correctif-nav.zip -d temp6
cp temp6/bingr-correctif-nav/src/app/calendrier/page.tsx src/app/calendrier/page.tsx
cp "temp6/bingr-correctif-nav/src/app/media/[id]/page.tsx" "src/app/media/[id]/page.tsx"
cp temp6/bingr-correctif-nav/src/app/recherche/page.tsx src/app/recherche/page.tsx
rm -rf temp6 bingr-correctif-nav.zip
npm run dev
```
