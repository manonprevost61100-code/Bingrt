# Bingr — Lot 3 : Écran Accueil

## Contenu

- `src/app/page.tsx` — remplace la page provisoire par le vrai tableau de
  bord : "En cours" (progression réelle calculée à partir des épisodes vus),
  "À venir cette semaine" (dates de diffusion réelles des épisodes déjà en
  base pour tes titres suivis), et "Ton activité récente"

## Note importante sur l'activité

Le flux d'activité montre pour l'instant **ta propre activité** (les tiens
uniquement) — pas encore celle des amis, puisque le système de follow/social
n'existe pas encore (ce sera le lot Social, avec l'écran dédié). C'est
volontaire, pas un bug.

## Installation

```bash
cp src/app/page.tsx <ton-projet>/src/app/page.tsx
npm run dev
```

Un seul fichier cette fois, pas besoin de zip complexe — tu peux même copier-
coller directement le contenu dans l'éditeur si tu préfères.

## Pour tester "À venir cette semaine"

Comme les dates de diffusion sont souvent dans le passé pour des séries déjà
terminées (comme L'Attaque des Titans), cette section restera vide pour ce
titre — normal. Pour la tester, importe une série encore en diffusion (via la
recherche) et marque-la comme suivie.

## Prochain lot

Lot 4 : **Profil / Stats** (temps total, badges, genres préférés) — ou si tu
préfères, on peut faire le **Calendrier** en premier, vu qu'on a déjà la
logique de dates en place ici. Dis-moi ce que tu préfères.
