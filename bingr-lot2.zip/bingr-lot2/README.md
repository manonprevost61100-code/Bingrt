# Bingr — Lot 2 : Recherche + Fiche média

## Contenu

- `src/app/recherche/page.tsx` — recherche TMDB en direct (debounce simple),
  filtres Tout/Séries/Films/Animes, clic sur un résultat → import + redirection
- `src/app/api/media/import/route.ts` — importe un média TMDB vers ta base
  (et toutes ses saisons/épisodes s'il s'agit d'une série ou d'un anime)
- `src/app/media/[id]/page.tsx` — fiche média : synopsis, genres, statut de
  visionnage, liste des épisodes par saison avec cases à cocher
- `src/app/api/media/[id]/status/route.ts` — change le statut (à voir / en
  cours / terminé / abandonné)
- `src/app/api/episodes/[id]/toggle/route.ts` — coche/décoche un épisode vu
- `src/components/WatchStatusButtons.tsx` et `EpisodeCheckbox.tsx` — les deux
  petits composants interactifs de la fiche
- `src/types/next-auth.d.ts` — corrige le typage TypeScript de
  `session.user.id` (sinon erreur de compilation)
- `schema-a-jour.prisma` — **référence uniquement**, pour vérifier que ton
  schéma local a bien le champ `emailVerified` ajouté au lot précédent. Ne pas
  écraser ton fichier actuel avec, juste comparer si besoin.

## Installation

1. Décompresse ce zip et copie son contenu (dossier `src/` fusionné avec
   l'existant) à la racine de ton projet, comme pour le lot précédent :
   ```bash
   unzip bingr-lot2.zip -d temp3
   cp -r temp3/bingr-lot2/src/* src/
   rm -rf temp3 bingr-lot2.zip
   ```
   (le `schema-a-jour.prisma` reste dans `temp3`, pas besoin de le copier)

2. Redémarre le serveur :
   ```bash
   npm run dev
   ```

3. Connecte-toi, clique "Aller à la recherche", tape un titre (ex: "Attack on
   Titan" pour tester la détection anime), clique un résultat → tu dois
   atterrir sur sa fiche avec les épisodes de la saison 1 déjà listés.

## Tester

- Coche quelques épisodes → le compteur "X / Y vus" doit se mettre à jour au
  rechargement de la page.
- Change le statut de visionnage → reviens sur la fiche plus tard, le bouton
  actif doit être resté sélectionné (c'est stocké en base).

## Prochain lot

Lot 3 : l'écran **Accueil** (séries en cours avec progression, calendrier des
sorties, activité — pour l'instant on a testé chaque brique isolément).
