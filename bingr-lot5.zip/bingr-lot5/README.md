# Bingr — Lot 5 : Profil / Stats

## Contenu

- `src/app/profil/page.tsx` — nouvel écran : temps total regardé (calculé à
  partir des vrais runtimes d'épisodes, 24 min par défaut si TMDB ne l'a pas
  renseigné), nombre d'épisodes vus, titres terminés, et répartition des
  genres préférés (pondérée par nombre d'épisodes vus par genre)
- `src/app/page.tsx` — mis à jour avec un lien 👤 vers le profil

## Note sur les badges

Section "Badges" présente sur l'écran mais avec un message "arrivent
bientôt" — les badges ont besoin d'une petite table de règles (ex: "10
séries terminées") qu'on posera dans un lot dédié pour rester propre, plutôt
que de la bricoler ici.

## Installation

```bash
git pull
unzip bingr-lot5.zip -d temp7
mkdir -p src/app/profil
cp temp7/bingr-lot5/src/app/profil/page.tsx src/app/profil/page.tsx
cp temp7/bingr-lot5/src/app/page.tsx src/app/page.tsx
rm -rf temp7 bingr-lot5.zip
npm run dev
```

## Prochain lot

Soit les **Badges** (règles + calcul), soit directement le **Wrapped**
annuel, soit le **Social** (follow + feed d'amis). Dis-moi ce qui te tente.
