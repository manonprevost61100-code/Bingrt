# Bingr — Lot 4 : Calendrier

## Contenu

- `src/app/calendrier/page.tsx` — nouvel écran : grille du mois navigable
  (flèches ← / →), jours marqués selon les sorties prévues, et une liste
  chronologique des 10 prochaines sorties toutes confondues en dessous
- `src/app/page.tsx` — mis à jour avec un lien 📅 vers le calendrier dans le
  header de l'accueil

## Installation

```bash
git pull
unzip bingr-lot4.zip -d temp5
mkdir -p src/app/calendrier
cp temp5/bingr-lot4/src/app/calendrier/page.tsx src/app/calendrier/page.tsx
cp temp5/bingr-lot4/src/app/page.tsx src/app/page.tsx
rm -rf temp5 bingr-lot4.zip
npm run dev
```

## Tester

Comme pour "À venir cette semaine", ça ne s'affichera que pour des séries
encore en diffusion (une série terminée comme L'Attaque des Titans n'aura
aucune date future). Importe une série en cours de diffusion via la
recherche et marque-la comme suivie pour voir des jours marqués sur le
calendrier.

## Prochain lot

Profil / Stats — temps total, badges, genres préférés.
